IconMenu = {

}

function IconMenu.OpenMenu(List, configs)
    exports.icon_menu:OpenMenu(List, configs)
end

function IconMenu.ForceCloseMenu()
    exports.icon_menu:ForceCloseMenu()
end