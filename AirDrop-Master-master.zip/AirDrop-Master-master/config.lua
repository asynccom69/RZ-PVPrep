config = {}

config.max = 10
config.items = {
	"copper",
	"iron",
	"gold",
	"diamond"
}