# AirDrop-Master
FiveM Command Spawn AirDrop

#### HOW TO USE AIRDROP ####

/airdrop (Admin Only!!!)

############################
